from setuptools import setup

setup(
    name="genysis",
    version="0.0.1",
    scripts=['genysis.py']
)
